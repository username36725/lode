﻿using System;
using System.Reflection.Emit;
using System.Windows;
using System.Drawing;

using System.Windows.Controls;
using System.Windows.Media;

namespace lode
{
    /// <summary>
    /// Interakční logika pro Window1.xaml
    /// </summary>
    public partial class Window1 : Window

    {
       
        public void M(int a, int b) 
        {
            int c = a + b;
            TB1.Text = c.ToString();
        }

        int RandomInt;
        public int Znak;
        private void BRandom_Click(object sender, EventArgs e)
        {
            int[,] iArray = new int[5, 5];
            Random rnumber = new Random();
            int inum;
            string temp = "";

            for (int x = 0; x < iArray.GetLength(0); x++)
            {
                for (int y = 0; y < iArray.GetLength(1); y++)
                {
                    inum = rnumber.Next(0, 2); // includes 9 but excludes 10
                    iArray[x, y] = inum;
                    temp += inum.ToString() + " ";
                }
                if (x < iArray.GetLength(0) - 1) temp += "\r\n";
            }
            
            TB1.Text = temp;
        }
        public void Vypsat()
        {

        }
        public void Umisteni(int Sloupec, int Radek)
        {
          

          
            Canvas rectangle;
            {
                Height = 15;
                Width = 15; 
         
           
           
 };
            

            int[,] Pole2= new int[5, 5];
            if (Pole1[Sloupec, Radek] == 0)
            {
                Pole1[Sloupec, Radek] = 1;
            }

        }

        public void Podminka()
        {
            //  if (Pole1[Sloupec])

        }

        public int Lod;
        int[,] Pole1 = new int[5, 5];

        public Window1()
        {
            InitializeComponent();
            if (Pole1[4, 4] == 1) { TB1.Text = "a"; }


           
          //  Pole1[4,3] = 1;
        }
private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
        }
        private void B00_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(0, 0);
            if (Pole1[1,1] == 1) 
            {
                TB1.Text = "a";
            }
            if (Pole1[1,1] == 0  ) 
            {
                TB1.Text = "b";
                    }
        }

        private void B01_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(0, 1);
            TB1.Text = "a";
        }

        private void B02_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(0, 2);
        }
        private void B03_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(0, 3);
        }
        private void B04_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(0, 4);
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void B10_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(1, 0);
            
        }

        private void B11_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(1, 1);
        }

        private void B12_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(1, 2);
        }

        private void B13_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(1, 3);
        }

        private void B14_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(1, 4);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void B20_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(2, 0);
        }

        private void B21_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(2, 1);
        }

        private void B22_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(2, 2);
        }

        private void B23_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(2, 3);
        }
        private void B24_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(2, 4);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void B30_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(3, 0);
        }

        private void B31_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(3, 1);
        }

        private void B32_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(3, 2);
        }

        private void B33_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(3, 3);
        }

        private void B34_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(3, 4);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void B40_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(4, 0);
        }

        private void B41_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(4, 1);
        }

        private void B42_Click(object sender, RoutedEventArgs e)
        {
            Umisteni(4, 2);
        }

        private void B43_Click(object sender, RoutedEventArgs e)
        {
            //Umisteni(4, 3);
            TB1.Text = Pole1[4,3].ToString();
        }

        private void B44_Click(object sender, RoutedEventArgs e)
        {
            //Umisteni(4, 4);
            //Pole1[4, 4] = 5;
            //Pole1[4,4] = 1;
            
           // B44.Click += Pole1[4, 4] = 1;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            /*  string s1 = TB1.Text;
              string s0;


              for (int j = 0; j < Pole1.GetLength(1); j++)
              {
                  for (int i = 0; i < Pole1.GetLength(0); i++)
                  {
                       Console.Write(Pole1[i, j]);
                  }
                //  new TB1.WriteLine();
              }
            */
            /*  if (Pole1[4,4] == 5) {
                 TB1.Text = "A"; 
              }
              if (Pole1[4, 4] == 0)
              {
                  TB1.Text = "B";
              }
              if (Pole1[4, 4] == null )
              {
                  TB1.Text = "c";
              }*/
           
            
        }
        private void BMenu_Click(object sender, RoutedEventArgs e) 
        {
            Close();
            //MainWindow win1.Show();
            
            
        }
      

    }
}
